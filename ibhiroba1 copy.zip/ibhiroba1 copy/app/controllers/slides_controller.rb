class SlidesController < ApplicationController
  def show
  end
end
