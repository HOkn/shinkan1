class SchoolsController < ApplicationController
  def index
  end
end
